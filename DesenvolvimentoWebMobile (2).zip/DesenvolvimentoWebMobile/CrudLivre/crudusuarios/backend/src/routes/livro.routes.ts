import { Router } from 'express';
import * as livroController from '../controllers/livro.controller';

const router = Router();

router.get('/livros', livroController.index);
router.get('/livros/:id', livroController.show);
router.post('/livros', livroController.store);
router.put('/livros/:id', livroController.update);
router.patch('/livros/:id', livroController.patch);
router.delete('/livros/:id', livroController.destroy);

export default router;