import pool from '../config/database';
// Atenção: Lembre-se de criar/renomear o arquivo de tipos para 'livro.ts'
import { Livro, LivroFilters, CreateLivroDTO } from '../types/livro';
 
export async function findAll(filters: LivroFilters = {}): Promise<Livro[]> {
  let query = 'SELECT * FROM livros WHERE 1=1';
  const values: unknown[] = [];
 
  // Filtrando por título (antes era name)
  if (filters.titulo) {
    values.push(`%${filters.titulo}%`);
    query += ` AND titulo ILIKE $${values.length}`;
  }
  // Filtrando por lido (antes era status)
  if (filters.lido !== undefined) {
    values.push(filters.lido);
    query += ` AND lido = $${values.length}`;
  }
 
  query += ' ORDER BY id';
  const result = await pool.query(query, values);
  return result.rows;
}
 
export async function findById(id: number): Promise<Livro | undefined> {
  const result = await pool.query(
    'SELECT * FROM livros WHERE id = $1',
    [id]
  );
  return result.rows[0];
}
 
export async function create(data: CreateLivroDTO): Promise<Livro> {
  const { titulo, autor, ano_publicacao, lido } = data;
  const result = await pool.query(
    `INSERT INTO livros (titulo, autor, ano_publicacao, lido)
     VALUES ($1, $2, $3, $4) RETURNING *`,
    [titulo, autor, ano_publicacao, lido]
  );
  return result.rows[0];
}
 
export async function update(id: number, data: CreateLivroDTO): Promise<Livro> {
  const { titulo, autor, ano_publicacao, lido } = data;
  const result = await pool.query(
    `UPDATE livros SET titulo=$1, autor=$2, ano_publicacao=$3, lido=$4
     WHERE id=$5 RETURNING *`,
    [titulo, autor, ano_publicacao, lido, id]
  );
  return result.rows[0];
}
 
export async function patch(id: number, fields: Partial<CreateLivroDTO>): Promise<Livro> {
  const keys = Object.keys(fields) as (keyof CreateLivroDTO)[];
  const sets = keys.map((k, i) => `${k} = $${i + 1}`).join(', ');
  const values = [...keys.map(k => fields[k]), id];
 
  const result = await pool.query(
    `UPDATE livros SET ${sets} WHERE id = $${values.length} RETURNING *`,
    values
  );
  return result.rows[0];
}
 
export async function remove(id: number): Promise<void> {
  await pool.query('DELETE FROM livros WHERE id = $1', [id]);
}