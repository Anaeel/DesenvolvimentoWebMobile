import { Request, Response } from 'express';
import * as livroService from '../services/livro.service';

export async function index(req: Request, res: Response): Promise<void> {
  const { titulo, lido } = req.query;
  const filters: { titulo?: string; lido?: boolean } = {};
  if (titulo) filters.titulo = String(titulo);
  if (lido !== undefined) filters.lido = lido === 'true';

  const livros = await livroService.listLivros(filters);
  res.json(livros);
}

export async function show(req: Request, res: Response): Promise<void> {
  const livro = await livroService.getLivro(Number(req.params.id));
  res.json(livro);
}

export async function store(req: Request, res: Response): Promise<void> {
  const livro = await livroService.createLivro(req.body);
  res.status(201).json(livro);
}

export async function update(req: Request, res: Response): Promise<void> {
  const livro = await livroService.updateLivro(Number(req.params.id), req.body);
  res.json(livro);
}

export async function patch(req: Request, res: Response): Promise<void> {
  const livro = await livroService.patchLivro(Number(req.params.id), req.body);
  res.json(livro);
}

export async function destroy(req: Request, res: Response): Promise<void> {
  await livroService.deleteLivro(Number(req.params.id));
  res.status(204).send();
}