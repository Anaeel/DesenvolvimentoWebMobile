import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
// 1. Alteramos a importação para apontar para o novo arquivo de rotas
import livroRoutes from './routes/livro.routes';

const app = express();

app.use(cors());
app.use(express.json());

// 2. Alteramos o uso para o roteador de livros
app.use('/api', livroRoutes);

app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  console.error(err);
  res.status(500).json({ error: 'Erro interno no servidor' });
});

export default app;