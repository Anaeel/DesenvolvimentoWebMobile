export interface Livro {
  id: number;
  titulo: string;
  autor: string;
  ano_publicacao: number;
  lido: boolean;
  created_at?: Date;
}

export interface LivroFilters {
  titulo?: string;
  lido?: boolean;
}

export interface CreateLivroDTO {
  titulo: string;
  autor: string;
  ano_publicacao: number;
  lido: boolean;
}