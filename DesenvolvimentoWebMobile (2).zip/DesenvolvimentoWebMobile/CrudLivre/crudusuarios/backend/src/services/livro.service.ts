import * as livroRepository from '../repositories/livro.repository';
import { Livro, LivroFilters, CreateLivroDTO } from '../types/livro';

export async function listLivros(filters: LivroFilters): Promise<Livro[]> {
  return livroRepository.findAll(filters);
}

export async function getLivro(id: number): Promise<Livro> {
  const livro = await livroRepository.findById(id);
  if (!livro) {
    throw new Error('Livro não encontrado');
  }
  return livro;
}

export async function createLivro(data: CreateLivroDTO): Promise<Livro> {
  return livroRepository.create(data);
}

export async function updateLivro(id: number, data: CreateLivroDTO): Promise<Livro> {
  await getLivro(id);
  return livroRepository.update(id, data);
}

export async function patchLivro(id: number, fields: Partial<CreateLivroDTO>): Promise<Livro> {
  await getLivro(id);
  return livroRepository.patch(id, fields);
}

export async function deleteLivro(id: number): Promise<void> {
  await getLivro(id);
  await livroRepository.remove(id);
}