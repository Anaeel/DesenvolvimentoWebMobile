import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Livro } from '../models/livro.model';

@Injectable({ providedIn: 'root' })
export class LivroService {
  private apiUrl = 'http://localhost:3000/api/livros';

  constructor(private http: HttpClient) {}

  list(filters?: { titulo?: string; lido?: boolean }): Observable<Livro[]> {
    let params = new HttpParams();
    if (filters?.titulo) params = params.set('titulo', filters.titulo);
    if (filters?.lido !== undefined) params = params.set('lido', String(filters.lido));
    return this.http.get<Livro[]>(this.apiUrl, { params });
  }

  getById(id: number): Observable<Livro> {
    return this.http.get<Livro>(`${this.apiUrl}/${id}`);
  }

  create(livro: Livro): Observable<Livro> {
    return this.http.post<Livro>(this.apiUrl, livro);
  }

  update(id: number, livro: Livro): Observable<Livro> {
    return this.http.put<Livro>(`${this.apiUrl}/${id}`, livro);
  }

  patch(id: number, fields: Partial<Livro>): Observable<Livro> {
    return this.http.patch<Livro>(`${this.apiUrl}/${id}`, fields);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}