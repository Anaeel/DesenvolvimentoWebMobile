import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Livro } from '../../models/livro.model';
import { LivroService } from '../../services/livro.service';

@Component({
  selector: 'app-livro-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './livro-form.component.html'
})
export class UserFormComponent implements OnInit {
  livro: Livro = { titulo: '', autor: '', lido: false };
  id?: number;

  constructor(
    private livroService: LivroService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const paramId = this.route.snapshot.paramMap.get('id');
    if (paramId) {
      this.id = Number(paramId);
      this.livroService.getById(this.id).subscribe(livro => (this.livro = livro));
    }
  }

  save(): void {
    const request = this.id
      ? this.livroService.update(this.id, this.livro)
      : this.livroService.create(this.livro);

    request.subscribe(() => this.router.navigate(['/']));
  }
}