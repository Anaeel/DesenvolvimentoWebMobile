import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { Livro } from '../../models/livro.model';
import { LivroService } from '../../services/livro.service';

@Component({
  selector: 'app-livro-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './livro-list.component.html'
})
export class UserListComponent implements OnInit {
  livros: Livro[] = [];
  searchTitulo = '';

  constructor(private livroService: LivroService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.livroService.list({ titulo: this.searchTitulo })
      .subscribe(livros => (this.livros = livros));
  }

  remove(id: number): void {
    this.livroService.delete(id).subscribe(() => this.load());
  }
}