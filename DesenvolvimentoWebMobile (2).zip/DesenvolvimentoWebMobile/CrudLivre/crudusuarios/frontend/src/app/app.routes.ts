import { Routes } from '@angular/router';
import { UserListComponent } from './components/livro-list/livro-list.component';
import { UserFormComponent } from './components/livro-form/livro-form.component';

export const routes: Routes = [
  { path: '', component: UserListComponent },
  { path: 'novo', component: UserFormComponent },
  { path: 'editar/:id', component: UserFormComponent }
];
