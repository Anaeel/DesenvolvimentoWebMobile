export interface Livro {
  id?: number;
  titulo: string;
  autor: string;
  ano_publicacao?: number;
  lido?: boolean;
  created_at?: string;
}